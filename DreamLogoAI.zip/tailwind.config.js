export default {
  content: ["./index.html", "./App.jsx"],
  theme: {
    extend: {},
  },
  plugins: [],
}