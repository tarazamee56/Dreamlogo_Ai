import React, { useState } from "react";

function App() {
  const [prompt, setPrompt] = useState("");
  const [image, setImage] = useState("");

  const generateLogo = async () => {
    setImage("https://via.placeholder.com/300x300.png?text=Your+AI+Logo"); // Replace with real API if needed
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center px-4">
      <h1 className="text-4xl font-bold mb-6 text-center">DreamLogo AI</h1>
      <input
        type="text"
        placeholder="Enter logo idea..."
        value={prompt}
        onChange={(e) => setPrompt(e.target.value)}
        className="p-2 w-full max-w-md rounded text-black"
      />
      <button
        onClick={generateLogo}
        className="bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 mt-4 rounded"
      >
        Generate Logo
      </button>
      {image && <img src={image} alt="Generated Logo" className="mt-6 w-64 h-64 object-contain" />}
    </div>
  );
}

export default App;